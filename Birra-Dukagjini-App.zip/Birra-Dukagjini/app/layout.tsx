import "./globals.css";
export const metadata={title:"Birra Dukagjini · Prodhimi",description:"Zierjet, tanket dhe kontrolli i cilësisë për Birrën Dukagjini."};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="sq"><body>{children}</body></html>}
