import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";
export const brewery = sqliteTable("brewery", { id: text("id").primaryKey(), content: text("content").notNull(), revision: integer("revision").notNull().default(0) });
